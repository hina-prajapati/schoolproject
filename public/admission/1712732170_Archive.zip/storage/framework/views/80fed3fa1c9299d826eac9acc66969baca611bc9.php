<link href="<?php echo e(asset('/css/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/css/datatables/colReorder.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/css/datatables/buttons.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

<!-- <link href="<?php echo e(asset('/css/datatables/responsive.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" /> --><?php /**PATH /Users/shaikhabdulshahid/Project/spcode/erp/resources/views/layouts/style_loaders/datatable_loader.blade.php ENDPATH**/ ?>