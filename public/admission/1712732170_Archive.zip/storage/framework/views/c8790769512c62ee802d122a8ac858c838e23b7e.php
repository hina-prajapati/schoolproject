
<?php $__env->startSection('custom-styles'); ?>
    
    <?php echo $__env->make('layouts.style_loaders.token_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.style_loaders.datatable_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"  />
    <style type="text/css">
        .form-inline {
            display: grid;
        }
        #tablesource_length label{
            display: inline;
        }
        .margin-fa-icon{
            margin-left : 5px;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            margin-left: 10px;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            border: 0px;
        }
        .pagination {
             display: inline-flex; 
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body">
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block" id="flashMessage" style="margin-top: 10px;">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('danger')): ?>
                                <div class="alert alert-danger alert-block" id="flashMessage">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>

                            <div class="col-md-12" align="right">
                                <button class="btn btn-primary" style="margin-bottom:20px ;"><a href="<?php echo e(route(Request::segment(1).'.create')); ?>" style="color:#fff">Add <?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></a></button>
                            </div>
                            <div class="table-responsive">
                                <table id="tablesource" class="table display compact table-striped table-bordered  hover nowrap dataTable" cellspacing="0" role="grid" width="100%">
                                    <thead>
                                        <tr>
                                            <?php $__currentLoopData = $data['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class = "thead_<?php echo e($column); ?>"><?php echo e(ucwords(str_replace('_', ' ', $column))); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <?php $__currentLoopData = $data['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(in_array($key ,$data['disable_footer_search'])): ?>
                                                    <th class = "tfoot_<?php echo e($column); ?> no-search"> <?php echo e(ucwords(str_replace('_', ' ', $column))); ?> </th>
                                                <?php else: ?>
                                                    <th class = "tfoot_<?php echo e($column); ?>"> <?php echo e(ucwords(str_replace('_', ' ', $column))); ?> </th>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('php-to-js'); ?>
    <?php
        $js_data = array();
        $js_data['env'] = env('APP_ENV');
        $js_data['columns'] = $data['columns'];
        $js_data['pk'] = $data['pk'];
        $js_data['prefix'] = $data['prefix'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-scripts'); ?>

    <?php echo $__env->make('layouts.script_loaders.datatable_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.script_loaders.excel_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('/js/common/bootbox.min.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            var action_obj = [{
                class : "",
                title : "Edit",
                url : "/edit",
                href : true,
                i : {
                    class : "fa fa-pencil"
                }
            }, {
                class : "delete",
                title : "Delete",
                url : "",
                href : false,
                i : {
                    class : "fa fa-trash margin-fa-icon"
                }
            }];
            
            var datatable_object = {
                table_name : 'tablesource',
                order : {
                    state: false,
                    column : 1,
                    mode : "asc"
                },
                buttons : {
                    state : true ,
                    colvis : true,
                    excel : {
                        state: true,
                        columns: [':visible'] 
                    },
                    pdf : {
                        state: true,
                        columns: [':visible'] 
                    },
                },
                info : true,
                paging : true,
                searching : true,
                ordering : true,
                iDisplayLength: 10,
                sort_disabled_targets : [],
                ajax_url : window.location.href,
                column_data : datatableColumn(lang.columns, action_obj, lang.pk),
            }

            table = datatableInitWithButtonsAndDynamicRev(datatable_object);
                        
            // statusChange();

            $(document).on('click', '.delete', function() {
                var url = $(this).attr('data-url');
                bootbox.confirm("Are you sure you want to delete this record!", function(result) { 
                    console.log('This was logged in the callback: ' + result);
                    // once ajax is fired will hit the destroy function of controller. No need for route
                    if(result) {
                        $.ajax({
                            url:url,
                            type:"DELETE",
                            success: function(res) {
                                console.log(res);                                
                                window.location.href = "<?php echo e(route(Request::segment(1).'.index')); ?>";
                            }
                        })
                    } 
                });
            });
        });

        $(document).ready(function(){
            $(".alert").delay(9000).slideUp(500);
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sp\admin-panel-erp\resources\views/employees/index.blade.php ENDPATH**/ ?>