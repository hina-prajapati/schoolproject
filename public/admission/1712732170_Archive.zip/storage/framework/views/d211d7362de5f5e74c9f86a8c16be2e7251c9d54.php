
<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">
    <!-- Multi Select Css -->
    <link rel="stylesheet" href="/assets/plugins/multi-select/css/multi-select.css">

    <style>
        .ms-container .ms-list {
            height: 500px;
        }

        .ms-container .ms-optgroup-label {
            color: #000;
            font-weight: bold;
        }
        .select2-container-multi{
            width: 100%;
            min-height: 40px;
            border: 1px solid #000;
            border-radius:1px;
        }
        
        .ul-list { 
            list-style: none;
        }

        .treeview li {
            padding: 2px 0 2px 16px;
        }

        .inputcheckbox  {
            height: 16px;
            width: 16px;
            margin-right:10px;
            margin-top:0;
        }

        /*.ul-list li label{
            display: block;
        }*/

        .nowrap1 {
            white-space: nowrap;
        }

        .treeview{
            padding-left:0px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->assign_check_lists_id)): ?>
                                <form action="<?php echo e(route('updateAssignCheckLists')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->assign_check_lists_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route('assign-check-lists.store'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <?php if($errors->any()): ?>
                                        <div class="col-md-12">
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-md-12">
                                        <div class="form-group child-class">
                                            <label>Client: </label>
                                            <select class="form-control show-tick ms select2" aria-label="Default select example" id="client_id" name="client_id" data-placeholder="Select Client">
                                                <option value="">Select Client</option>
                                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->users_id); ?>"><?php echo e($value->email); ?> (<?php echo e($value->type_of_establishment); ?>)</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div> 

                                        <div class="row clearfix">
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <div class="card">
                                                    <div class="header">
                                                        <h2> <strong>Laws:</strong> Check List</h2>
                                                    </div>
                                                    <div class="body" id="page-wrap">
                                                        <input type="text" class="form-control mb-2" id="myInput" onkeyup="myFunction()" placeholder="Search for check list.." title="Type in a name">

                                                        <?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(isset($checklist[$value->laws_id])): ?>
                                                                <ul class="treeview ul-list">
                                                                    <li>
                                                                        <input type="checkbox" name="laws-<?php echo e($value->laws_id); ?>" id="laws" class="inputcheckbox">
                                                                        <label for="laws" class="custom-unchecked">
                                                                            <?php echo e($value->law_name); ?>

                                                                        </label>

                                                                        <ul class="ul-list">
                                                                            <?php $__currentLoopData = $checklist[$value->laws_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if(in_array($val->check_lists_id, $selected)): ?>
                                                                                    <li class="li-list">
                                                                                        <table>
                                                                                            <tr>
                                                                                                <td>
                                                                                                    <input type="checkbox" name="check_lists_id-<?php echo e($val->check_lists_id); ?>" id="check_lists_id-<?php echo e($val->check_lists_id); ?>"
                                                                                                    class="inputcheckbox" checked >
                                                                                                </td>
                                                                                                <td>
                                                                                                    <label for="check_lists_id-<?php echo e($val->check_lists_id); ?>" class="custom-unchecked nowrap"><?php echo e($val->evidence_advice); ?> (<b style="color:red;"><?php echo e($val->periodicity); ?></b>)</label>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </li>
                                                                                    
                                                                                <?php else: ?>
                                                                                    <li class="li-list">
                                                                                        <table>
                                                                                            <tr>
                                                                                                <td>
                                                                                                    <input type="checkbox" name="check_lists_id-<?php echo e($val->check_lists_id); ?>" id="check_lists_id-<?php echo e($val->check_lists_id); ?>" class="inputcheckbox" >
                                                                                                </td>
                                                                                                <td>
                                                                                                    <label for="check_lists_id-<?php echo e($val->check_lists_id); ?>" class="custom-unchecked nowrap"><?php echo e($val->evidence_advice); ?> (<b style="color:red;"><?php echo e($val->periodicity); ?></b>)</label>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </li>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </ul>
                                                                    </li> 
                                                                </ul>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                        

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/multi-select/js/jquery.multi-select.js"></script> <!-- Multi Select Plugin Js --> 

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->

<script type="text/javascript">
    $(function () {
        // $('#optgroup').multiSelect({ selectableOptgroup: true });
        // $('#optgroup').select2();
        //start code
        var select = $('#optgroup');

        function formatSelection(state) {
            return state.text;   
        }

        function formatResult(state) {
            console.log(state)
            if (!state.id) return state.text; // optgroup
            var id = 'state' + state.id.toLowerCase();
            var label = $('<label></label>', { for: id }).text(state.text);
            var checkbox = $('<input type="checkbox">', { id: id });
            
            return checkbox.add(label);   
        }

        select.select2({
            closeOnSelect: false,
            formatResult: formatResult,
            formatSelection: formatSelection,
            escapeMarkup: function (m) {
                return m;
            },
            matcher: function(term, text, opt){
                 return text.toUpperCase().indexOf(term.toUpperCase())>=0 || opt.parent("optgroup").attr("label").toUpperCase().indexOf(term.toUpperCase())>=0
            }
        });

        //end code

        $('.select2').select2();
        var check_lists_id = '';
        <?php if(isset($as->client_id)): ?>
            $('#client_id').select2().val(<?php echo e($as->client_id); ?>).trigger('change.select2');
            $('#laws_id').select2().val([<?php echo e($as->laws_id); ?>]).trigger('change.select2');
            $('#check_lists_id').select2().val([<?php echo e($as->check_lists_id); ?>]).trigger('change.select2');
            check_lists_id = [<?php echo e($as->check_lists_id); ?>];
            $('#laws_id').trigger('change');
        <?php endif; ?>
    });
    $('#laws_id').on('change', function(){
        var laws_id = $(this).val();
        if(laws_id.length > 0){
            $.ajax({
                type: 'post',
                url:'/get-check-list',
                data : {
                    laws_id : laws_id
                },
                success: function(res){
                    if (res.status == 200) {
                        $('#check_lists_id').empty();
                        $('#check_lists_id').val('');
                        var s = $('#check_lists_id');
                        $('<option />', { value : "", text : ""}).appendTo(s);
                        $.each(res['GC'], function( k, v ) {
                            $('<option />', { value : v.check_lists_id, text : v.check_lists_name}).appendTo(s);
                        });

                        if (check_lists_id.length) {
                            $('#check_lists_id').val([<?php echo e(isset($as->check_lists_id) ? $as->check_lists_id : ''); ?>]).trigger('change.select2');
                        }
                    }else{
                        $('#check_lists_id').val([]).trigger('change.select2');
                    }
                }       
            });
            
        }else{
           $('#check_lists_id').val([]).trigger('change.select2');
        }
    });

    $(function() {

      $('input[type="checkbox"]').change(checkboxChanged);

      function checkboxChanged() {
        var $this = $(this),
            checked = $this.prop("checked"),
            container = $this.parent(),
            siblings = container.siblings();

        container.find('input[type="checkbox"]')
        .prop({
            indeterminate: false,
            checked: checked
        })
        .siblings('label')
        .removeClass('custom-checked custom-unchecked custom-indeterminate')
        .addClass(checked ? 'custom-checked' : 'custom-unchecked');

        checkSiblings(container, checked);
      }

      function checkSiblings($el, checked) {
        var parent = $el.parent().parent(),
            all = true,
            indeterminate = false;

        $el.siblings().each(function() {
          return all = ($(this).children('input[type="checkbox"]').prop("checked") === checked);
        });

        if (all && checked) {
          parent.children('input[type="checkbox"]')
          .prop({
              indeterminate: false,
              checked: checked
          })
          .siblings('label')
          .removeClass('custom-checked custom-unchecked custom-indeterminate')
          .addClass(checked ? 'custom-checked' : 'custom-unchecked');

          checkSiblings(parent, checked);
        } 
        else if (all && !checked) {
          indeterminate = parent.find('input[type="checkbox"]:checked').length > 0;

          parent.children('input[type="checkbox"]')
          .prop("checked", checked)
          .prop("indeterminate", indeterminate)
          .siblings('label')
          .removeClass('custom-checked custom-unchecked custom-indeterminate')
          .addClass(indeterminate ? 'custom-indeterminate' : (checked ? 'custom-checked' : 'custom-unchecked'));

          checkSiblings(parent, checked);
        } 
        else {
          $el.parents("li").children('input[type="checkbox"]')
          .prop({
              indeterminate: true,
              checked: false
          })
          .siblings('label')
          .removeClass('custom-checked custom-unchecked custom-indeterminate')
          .addClass('custom-indeterminate');
        }
      }
    });


    function myFunction() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        li = document.querySelectorAll('.li-list');
        
        for (i = 0; i < li.length; i++) {
            table = li[i].getElementsByTagName("table")[0];
            txtValue = table.textContent || table.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                // li[i].style.visibility = "visible";
                li[i].style.display = "block";
            } else {
                li[i].style.display = "none";
                // li[i].style.visibility = "hidden";
            }
        }

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaikhabdulshahid/Project/spcode/erp/resources/views/assignchecklists/new_create.blade.php ENDPATH**/ ?>