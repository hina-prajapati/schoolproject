
<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->check_lists_id)): ?>
                                <form action="<?php echo e(route('updateCheckLists')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->check_lists_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route('check-lists.store'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="form-group child-class">
                                            <label>Law: </label>
                                            <select class="form-control show-tick ms select2"  id="laws_id" name="laws_id">
                                                <option value="">Select Laws</option>
                                                <?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->laws_id); ?>"><?php echo e($value->law_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>  

                                        <div class="form-group">
                                            <label>Check Lists Name: </label>
                                            <input type="text" class="form-control" id="check_lists_name" name="check_lists_name" value="<?php echo e(old('check_lists_name', (isset($as->check_lists_name)? $as->check_lists_name : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('check_lists_name')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('check_lists_name')); ?></p>
                                            <?php endif; ?>
                                        </div> 

                                        <div class="form-group">
                                            <label>Evidence Advice: </label>
                                            <input type="text" class="form-control" id="evidence_advice" name="evidence_advice" value="<?php echo e(old('evidence_advice', (isset($as->evidence_advice)? $as->evidence_advice : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('evidence_advice')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('evidence_advice')); ?></p>
                                            <?php endif; ?>
                                        </div> 

                                        <div class="form-group">
                                            <label>Compliance Description: </label>
                                            <input type="text" class="form-control" id="compliance_description" name="compliance_description" value="<?php echo e(old('compliance_description', (isset($as->compliance_description)? $as->compliance_description : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('compliance_description')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('compliance_description')); ?></p>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Section/Rules: </label>
                                            <input type="text" class="form-control" id="section_rules" name="section_rules" value="<?php echo e(old('section_rules', (isset($as->section_rules)? $as->section_rules : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('section_rules')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('section_rules')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                         
                                        <div class="form-group">
                                            <label>Risk: </label>
                                            <select class="form-control show-tick ms select2" id="risk" name="risk">
                                                <option value="">Select Risk</option>
                                                <?php $__currentLoopData = $risk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('risk')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('risk')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                        <div class="form-group">
                                            <label>Periodicity: </label>
                                            <select class="form-control show-tick ms select2" id="periodicity" name="periodicity">
                                                <option value="">Select Periodicity</option>
                                                <?php $__currentLoopData = $periodicity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Input Type: </label>
                                            <select class="form-control show-tick ms select2" id="input_type" name="input_type">
                                                <option value="">Select Input Type</option>
                                                <?php $__currentLoopData = $input_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>  

                                        <div class="form-group">
                                            <label>Start Month: </label>
                                            <select class="form-control show-tick ms select2" id="start_month" name="start_month">
                                                <option value="">Select Start Month</option>
                                                <?php for($month=1; $month<= 12; $month++): ?>
                                                    <?php
                                                        $num =  $month;
                                                        $num_padded = sprintf("%02d", $num);
                                                    ?>
                                                    <option value="<?php echo e($num_padded); ?>"><?php echo e(date("F", mktime(0, 0, 0, $month, 1))); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Type: </label>
                                            <select class="form-control show-tick ms select2" id="type" name="type">
                                                <option value="">Select Type</option>
                                                <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('type')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('type')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                        <div class="form-group child-class">
                                            <label>Category: </label>
                                            <select class="form-control show-tick ms select2"  id="category" name="category">
                                                <option value="">Select Category</option>
                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->category_id); ?>"><?php echo e($value->category); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->

<script src="/assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script> <!-- Input Mask Plugin Js --> 
<script type="text/javascript">
    $(function () {
        $('.select2').select2();
        <?php if(isset($as->laws_id)): ?>
            $('#risk').select2().val('<?php echo e($as->risk); ?>').trigger('change.select2');
            $('#type').select2().val('<?php echo e($as->type); ?>').trigger('change.select2');
            $('#laws_id').select2().val(<?php echo e($as->laws_id); ?>).trigger('change.select2');
            $('#category').select2().val(<?php echo e($as->category); ?>).trigger('change.select2');
            $('#input_type').select2().val(<?php echo e($as->input_type); ?>).trigger('change.select2');
            $('#periodicity').select2().val('<?php echo e($as->periodicity); ?>').trigger('change.select2');
            $('#start_month').select2().val('<?php echo e($as->start_month); ?>').trigger('change.select2');
        <?php endif; ?>
        // $('#due_date').inputmask('dd/mm/yyyy', { placeholder: '__/__/____' });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaikhabdulshahid/Project/spcode/erp/resources/views/checklists/create.blade.php ENDPATH**/ ?>