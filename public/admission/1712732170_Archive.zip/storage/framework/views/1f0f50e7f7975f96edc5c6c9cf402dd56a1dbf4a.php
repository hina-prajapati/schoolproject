
<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->users_id)): ?>
                                <form action="<?php echo e(route('updateVendor')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->users_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route(Request::segment(1).'.store'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="form-group child-class">
                                            <label>Select Client: </label>
                                            <select class="form-control show-tick ms select2"  id="client_id" name="client_id">
                                                <option value="">Select Client</option>
                                                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->users_id); ?>"><?php echo e($value->name." - ".$value->email); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Full Name: </label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', (isset($as->name)? $as->name : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('name')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('name')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                        <div class="form-group">
                                            <label>Mobile: </label>
                                            <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo e(old('mobile', (isset($as->mobile)? $as->mobile : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('mobile')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('mobile')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                        <div class="form-group">
                                            <label>Email: </label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', (isset($as->email)? $as->email : ''))); ?>" placeholder="Enter Email..">
                                            <?php if($errors->has('email')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('email')); ?></p>
                                            <?php endif; ?>
                                        </div> 
                                        <div class="form-group">
                                            <label>Password: </label>
                                            <div class="form-group">
                                                <input type="password" name="password" class="form-control" id="password" placeholder="Enter Password">
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label>Status:</label>

                                            <select class="form-control show-tick ms select2" data-placeholder="Select" name="status" id="status">
                                                <option value="active" <?php echo e(old('status', (isset($as->status)? $as->status : '')) == 'active' ? 'selected' : ''); ?>>Active</option>
                                                <option value="inactive" <?php echo e(old('status', (isset($as->status)? $as->status : '')) == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                            </select>
                                        </div>  

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->

<script src="/assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script> <!-- Input Mask Plugin Js --> 
<script type="text/javascript">
    $(function () {
        $('.select2').select2();
        <?php if(isset($as->client_id)): ?>
            $('#client_id').select2().val('<?php echo e($as->client_id); ?>').trigger('change.select2');
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sp\admin-panel-erp\resources\views/vendor/create.blade.php ENDPATH**/ ?>