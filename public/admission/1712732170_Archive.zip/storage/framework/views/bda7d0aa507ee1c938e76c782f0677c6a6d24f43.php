<script src="<?php echo e(asset('/js/datatables/jquery.dataTables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/dataTables.bootstrap.min.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('/js/datatables/dataTables.colReorder.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/dataTables.buttons.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/buttons.bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/buttons.colVis.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/jszip.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/pdfmake.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/vfs_fonts.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/buttons.html5.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/datatables/dataTables.responsive.js')); ?>" type="text/javascript"></script>
<!-- <script src="<?php echo e(asset('/js/datatables/sum().js')); ?>" type="text/javascript"></script> -->



<!-- cdn commented and used aboveas local file -->
<!-- <script src="https://cdn.datatables.net/responsive/1.0.3/js/dataTables.responsive.js" type="text/javascript"></script> -->

<!-- <script src="<?php echo e(asset('/js/datatables/dataTables.responsive.min.js')); ?>" type="text/javascript"></script> -->
<!-- <script src="<?php echo e(asset('/js/datatables/responsive.bootstrap.min.js')); ?>" type="text/javascript"></script> --><?php /**PATH C:\sp\admin-panel-erp\resources\views/layouts/script_loaders/datatable_loader.blade.php ENDPATH**/ ?>