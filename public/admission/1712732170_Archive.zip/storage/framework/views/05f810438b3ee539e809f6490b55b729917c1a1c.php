<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Admin Panel">
	<title>Admin Panel | <?php echo $__env->yieldContent('htmlheader_title', 'Dashboard'); ?></title>
	<link rel="icon" href="favicon.ico" type="image/x-icon"> <!-- Favicon-->
	<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">
	
	

	<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/morrisjs/morris.min.css')); ?>"/>

	<!-- Custom Css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.min.css')); ?>">
	<style type="text/css">
		.alert .close {
		    margin-top: 10px;
		}
	</style>
	<?php echo $__env->yieldContent('custom-styles'); ?>
</head><?php /**PATH C:\sp\admin-panel-erp\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>