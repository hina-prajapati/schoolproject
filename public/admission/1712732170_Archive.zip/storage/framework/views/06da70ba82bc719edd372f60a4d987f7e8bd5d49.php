<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">
    <!-- Multi Select Css -->
    <link rel="stylesheet" href="/assets/plugins/multi-select/css/multi-select.css">

    <style>
        .ms-container .ms-list {
            height: 500px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->assign_check_lists_id)): ?>
                                <form action="<?php echo e(route('updateAssignCheckLists')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->assign_check_lists_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route('assign-check-lists.store'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <?php if($errors->any()): ?>
                                        <div class="col-md-12">
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-md-12">
                                        <div class="form-group child-class">
                                            <label>Client: </label>
                                            <select class="form-control show-tick ms select2" aria-label="Default select example" id="client_id" name="client_id" data-placeholder="Select Client">
                                                <option value="">Select Client</option>
                                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->users_id); ?>"><?php echo e($value->email); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div> 


                                        <div class="row clearfix">
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <div class="card">
                                                    <div class="header">
                                                        <h2> <strong>Laws:</strong> Check List</h2>
                                                        
                                                    </div>
                                                    <div class="body">
                                                        <select id="optgroup" class="ms" multiple="multiple" name="check_lists_id[]">
                                                            <?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(isset($checklist[$value->laws_id])): ?>
                                                                    <optgroup label="Laws - <?php echo e($value->law_name); ?>">
                                                                        <?php $__currentLoopData = $checklist[$value->laws_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if(in_array($val->check_lists_id, $selected)): ?>
                                                                                <option value="<?php echo e($val->check_lists_id); ?>" selected><?php echo e($val->evidence_advice); ?></option>
                                                                                
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($val->check_lists_id); ?>"><?php echo e($val->evidence_advice); ?></option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </optgroup>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                        

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/multi-select/js/jquery.multi-select.js"></script> <!-- Multi Select Plugin Js --> 

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->



<script type="text/javascript">
    $(function () {
        $('#optgroup').multiSelect({ selectableOptgroup: true });
        $('.select2').select2();
        var check_lists_id = '';
        <?php if(isset($as->client_id)): ?>
            $('#client_id').select2().val(<?php echo e($as->client_id); ?>).trigger('change.select2');
            $('#laws_id').select2().val([<?php echo e($as->laws_id); ?>]).trigger('change.select2');
            $('#check_lists_id').select2().val([<?php echo e($as->check_lists_id); ?>]).trigger('change.select2');
            check_lists_id = [<?php echo e($as->check_lists_id); ?>];
            $('#laws_id').trigger('change');
        <?php endif; ?>
    });
    $('#laws_id').on('change', function(){
        var laws_id = $(this).val();
        if(laws_id.length > 0){
            $.ajax({
                type: 'post',
                url:'/get-check-list',
                data : {
                    laws_id : laws_id
                },
                success: function(res){
                    if (res.status == 200) {
                        $('#check_lists_id').empty();
                        $('#check_lists_id').val('');
                        var s = $('#check_lists_id');
                        $('<option />', { value : "", text : ""}).appendTo(s);
                        $.each(res['GC'], function( k, v ) {
                            $('<option />', { value : v.check_lists_id, text : v.check_lists_name}).appendTo(s);
                        });

                        if (check_lists_id.length) {
                            $('#check_lists_id').val([<?php echo e(isset($as->check_lists_id) ? $as->check_lists_id : ''); ?>]).trigger('change.select2');
                        }
                    }else{
                        $('#check_lists_id').val([]).trigger('change.select2');
                    }
                }       
            });
            
        }else{
           $('#check_lists_id').val([]).trigger('change.select2');
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaikhabdulshahid/Project/spcode/erp/resources/views/assignchecklists/create_new.blade.php ENDPATH**/ ?>