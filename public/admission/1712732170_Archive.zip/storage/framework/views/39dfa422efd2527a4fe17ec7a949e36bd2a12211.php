
<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">

                <div class="col-lg-12">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block" id="flashMessage" style="margin-top: 10px;">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('danger')): ?>
                        <div class="alert alert-danger alert-block" id="flashMessage">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>

                    <div class="card">

                        <?php if($error = Session::get('usergroupdata_error')): ?>
                            <?php if(count($error) != 0): ?>
                                <button class="btn btn-danger" style="margin: 5px 0px 10px 8px;">
                                    <a href="<?php echo e(route('ErrorExcelDownload')); ?>" style="color: #fff;">Download excel</a>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <div class="body" >        
                            <form action="<?php echo url('check-lists/import'); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    <?php if($errors->any()): ?>
                                        <div class="col-md-12">
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-md-12">
                                        <div class="form-group child-class">
                                            <label>Law: </label>
                                            <select class="form-control show-tick ms select2"  id="laws_id" name="laws_id">
                                                <option value="">Select Laws</option>
                                                <?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->laws_id); ?>"><?php echo e($value->law_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>  
                                        <div class="form-group child-class">
                                            <label>Upload Excel: </label>
                                            <input type="file" name="select_file" class="form-control" />
                                            <?php if($errors->has('select_file')): ?>
                                                <p style="color:#dd4b39;"><?php echo e($errors->first('select_file')); ?>

                                            <?php endif; ?>
                                        </div>  


                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->
<script type="text/javascript">
    $(function () {
        $('.select2').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sp\admin-panel-erp\resources\views/checklists/importFile.blade.php ENDPATH**/ ?>