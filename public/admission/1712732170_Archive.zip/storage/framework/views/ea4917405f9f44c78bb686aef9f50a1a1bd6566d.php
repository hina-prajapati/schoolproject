
<?php $__env->startSection('custom-styles'); ?>
    
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->laws_id)): ?>
                                <form action="<?php echo e(route('updateLaws')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->laws_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route('laws.store'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Law Name: </label>
                                            <input type="text" class="form-control" id="law_name" name="law_name" value="<?php echo e(old('law_name', (isset($as->law_name)? $as->law_name : ''))); ?>" placeholder="Enter here..">
                                            <?php if($errors->has('law_name')): ?>
                                                <p style="color:#dd4b39"><?php echo e($errors->first('law_name')); ?></p>
                                            <?php endif; ?>
                                        </div> 

                                        <div class="form-group child-class">
                                            <label>Type of Establishment: </label>
                                            <select class="form-control show-tick ms select2"  id="type_of_establishment" name="type_of_establishment">
                                                <option value="">Select Type of Establishment</option>
                                                <?php $__currentLoopData = $type_of_establishment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div> 

                                        <div class="form-group">
                                            <label>Type of Govt: </label> <br>
                                            <?php $__currentLoopData = $type_of_govt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="radio inlineblock m-r-20">
                                                    <?php if(isset($as->type_of_govt) && $as->type_of_govt == $value): ?>
                                                        <input type="radio" name="type_of_govt" id="<?php echo e($value); ?>" class="with-gap" value="<?php echo e($value); ?>" checked>
                                                    <?php else: ?>
                                                        <input type="radio" name="type_of_govt" id="<?php echo e($value); ?>" class="with-gap" value="<?php echo e($value); ?>">
                                                    <?php endif; ?>
                                                    
                                                    <label for="<?php echo e($value); ?>"><?php echo e($value); ?></label>
                                                </div>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </div>

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>

<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->
<script src="/assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script> <!-- Input Mask Plugin Js --> 
<script type="text/javascript">
    $(function () {
        $('.select2').select2();

        <?php if(isset($as->type_of_establishment)): ?>
            $('#type_of_establishment').select2().val('<?php echo e($as->type_of_establishment); ?>').trigger('change.select2');
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sp\admin-panel-erp\resources\views/laws/create.blade.php ENDPATH**/ ?>