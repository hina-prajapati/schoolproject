<!-- Jquery Core Js --> 
<script src="/assets/bundles/libscripts.bundle.js"></script>
<script src="/assets/bundles/vendorscripts.bundle.js"></script> 

<script src="/assets/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="/assets/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="/assets/bundles/c3.bundle.js"></script>
<!-- Custom Js --> 
<script src="/assets/bundles/mainscripts.bundle.js"></script>

<script src="/assets/js/pages/index.js"></script>
<!-- All custom additions will be done here -->
<script src="<?php echo e(asset('/js/initial_loading.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/common/function.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/common/datatable_function.js')); ?>" type="text/javascript"></script>

<?php
    $js_data['env'] = env('APP_ENV');
	$js_data['errors'] = (isset($errors) && count($errors) > 0) ? $errors->toArray() : [];
    $js_data['user_id'] = isset(Auth::user()->emp_id) ? Auth::user()->emp_id : '';
?>
<?php echo $__env->yieldContent('php-to-js'); ?>

<script type="text/javascript">
    var lang = lang || {};
    $.extend(true, lang, <?php echo json_encode($js_data); ?>);
    errorDisplay();
</script>
<?php echo $__env->yieldContent('custom-scripts'); ?><?php /**PATH C:\sp\admin-panel-erp\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>