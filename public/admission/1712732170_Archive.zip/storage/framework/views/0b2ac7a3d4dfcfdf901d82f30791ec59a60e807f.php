<?php $__env->startSection('custom-styles'); ?>
    <link rel="stylesheet" href="/assets/plugins/select2/select2.css" />
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"  />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<?php
    $time = time();
?>
<style type="text/css">
    /*.btn-deletes{
        margin-left:15px;
    }*/
    .xl-green{
        padding : 10px 0px;
        margin-right : 10px;
    }
</style>
<section class="content">
    <div class="body_scroll">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="zmdi zmdi-home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucwords(str_replace('-', ' ', Request::segment(1)))); ?></li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">                
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>                                
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        
                        <div class="body" >        
                            <?php if(isset($as->audit_report_id)): ?>
                                <form action="<?php echo e(route('updateReply')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo e($as->audit_report_id); ?>">
                            <?php else: ?>
                                <form action="<?php echo route('updateReply'); ?>" method="POST" enctype="multipart/form-data">
                            <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="send_by_client" value="1">
                                <input type="hidden" name="send_by_employee" value="0">
                                <div class="row">
                                    <?php if($errors->any()): ?>
                                        <div class="col-md-12">
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-md-12">
                                        
                                        

                                        <?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law_key => $law_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3 class="text-center mb-0"><?php echo e($law_value); ?></h3>
                                                </div>
                                                <hr style="border: 2px solid blue; width:100%;">
                                                <?php $__currentLoopData = $checklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($law_key == $val->laws_id): ?>
                                                        <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>
                                                            <div class="row mt-2 ml-2 xl-green"style="width: 100%; ">
                                                        <?php else: ?>
                                                            <div class="row mt-2 ml-2"style="width: 100%; ">
                                                        <?php endif; ?>
                                                            <input type="hidden" name="check_lists_id[]" value="<?php echo e($val->check_lists_id); ?>">
                                                            
                                                            <div class="col-md-3"><?php echo e($val->evidence_advice); ?> <b class="text-danger">(<?php echo e($val->periodicity); ?>)</b></div>
                                                            <div class="col-md-4">
                                                                <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->emp_comments)): ?>
                                                                    <b><?php echo $c_a_r_s_data[$val->check_lists_id][0]->emp_comments; ?></b>
                                                                <?php else: ?>
                                                                    <b>-------------- No Comment -------------</b>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <select class="form-control show-tick ms select2" aria-label="Default select example" name="status<?php echo e($val->check_lists_id); ?>" data-placeholder="Select Client" disabled>
                                                                    <option value="">Select Status</option>
                                                                    <?php $__currentLoopData = $audit_report_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($value->audit_report_status_id); ?>" <?php echo e((isset($c_a_r_s_data[$val->check_lists_id]) ? $c_a_r_s_data[$val->check_lists_id][0]->status : '') == $value->audit_report_status_id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-2 text-center">
                                                                <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>

                                                                <?php else: ?>
                                                                    <button class="btn btn-primary addComments" check_lists_id=<?php echo e($val->check_lists_id); ?>  input_type=<?php echo e($val->input_type); ?>>
                                                                        +
                                                                    </button>
                                                                <?php endif; ?>
                                                                
                                                            </div>
                                                        </div>
                                                        <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>
                                                            <div class="row ml-2 xl-green" style="width:100%;" id="comments<?php echo e($val->check_lists_id); ?>" check_lists_id=<?php echo e($val->check_lists_id); ?>>
                                                        <?php else: ?>
                                                            <div class="row ml-2" style="width:100%;" id="comments<?php echo e($val->check_lists_id); ?>" check_lists_id=<?php echo e($val->check_lists_id); ?>>
                                                        <?php endif; ?>
                                                            
                                                            <?php if(isset($c_a_r_s_data[$val->check_lists_id])): ?>
                                                                <?php $__currentLoopData = $c_a_r_s_data[$val->check_lists_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_data => $value_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $time = $time+1;
                                                                    ?>
                                                                    <input type="hidden" name="client_audit_report_submit_id<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" value="<?php echo e($value_data->client_audit_report_submit_id); ?>">

                                                                    <?php if($val->input_type == 1): ?>
                                                                        <div class="col-md-10 mt-2 mainbox<?php echo e($time); ?>">
                                                                            <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>
                                                                                <input type="hidden" name="comments<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" value="<?php echo $value_data->comments; ?>">
                                                                                <textarea class="form-control"  rows="1" placeholder="Enter Here..." disabled="disabled"><?php echo $value_data->comments; ?></textarea>
                                                                            <?php else: ?>
                                                                                <textarea class="form-control"  rows="1" placeholder="Enter Here..." name="comments<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]"><?php echo $value_data->comments; ?></textarea>
                                                                            <?php endif; ?>
                                                                            

                                                                            <input type="hidden" name="files<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" class="form-control">
                                                                        </div>
                                                                    <?php elseif($val->input_type == 2): ?>
                                                                        <div class="col-md-10 mt-2 mainbox<?php echo e($time); ?>">
                                                                            <input type="hidden" name="comments<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]">

                                                                            <?php if(isset($value_data->files)): ?>
                                                                                <a href="/upload/audit_report/<?php echo e($as->audit_report_id); ?>/<?php echo e($value_data->files); ?>" download><?php echo e($value_data->files); ?></a>
                                                                                <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>

                                                                                <?php else: ?>
                                                                                    <button class="btn btn-danger btn-delete" client_audit_report_submit_id="<?php echo e($value_data->client_audit_report_submit_id); ?>" filedelte="true"><i class="fa fa-trash"></i> Delete</button>
                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <input type="file" name="files<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" class="form-control">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="col-md-7 mt-2 mainbox<?php echo e($time); ?>">
                                                                            <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>
                                                                                <input type="hidden" name="comments<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" value="<?php echo $value_data->comments; ?>">
                                                                                <textarea class="form-control"  rows="1" placeholder="Enter Here..." disabled="disabled"><?php echo $value_data->comments; ?></textarea>
                                                                            <?php else: ?>
                                                                                <textarea class="form-control"  rows="1" placeholder="Enter Here..." name="comments<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]"><?php echo $value_data->comments; ?></textarea>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="col-md-3 mt-2 mainbox<?php echo e($time); ?>">
                                                                            <?php if(isset($value_data->files)): ?>
                                                                                <a href="/upload/audit_report/<?php echo e($as->audit_report_id); ?>/<?php echo e($value_data->files); ?>" download><?php echo e($value_data->files); ?></a>
                                                                                <?php if((isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1)): ?>

                                                                                <?php else: ?>
                                                                                    <button class="btn btn-danger btn-delete" client_audit_report_submit_id="<?php echo e($value_data->client_audit_report_submit_id); ?>" filedelte="true"><i class="fa fa-trash"></i> Delete</button>
                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <input type="file" name="files<?php echo e($val->check_lists_id); ?>[<?php echo e($value_data->client_audit_report_submit_id); ?>]" class="form-control">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="col-md-2 mt-2 text-center mainbox<?php echo e($time); ?>">
                                                                        <?php if(isset($c_a_r_s_data[$val->check_lists_id][0]->status) && $c_a_r_s_data[$val->check_lists_id][0]->status == 1): ?>

                                                                        <?php else: ?>
                                                                            <button class="btn btn-danger btn-deletes btn-delete" check_lists_id="<?php echo e($val->check_lists_id); ?>" time="<?php echo e($time); ?>" client_audit_report_submit_id="<?php echo e($value_data->client_audit_report_submit_id); ?>" filedelte="false"  input_type=<?php echo e($val->input_type); ?>>
                                                                                - 
                                                                            </button>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <?php
                                                                    $time = $time+1;
                                                                ?>

                                                                <?php if($val->input_type == 1): ?>
                                                                    <div class="col-md-10 mt-2 mainbox<?php echo e($time); ?>">
                                                                        <textarea class="form-control" rows="1" placeholder="Enter Here..." name="comments<?php echo e($val->check_lists_id); ?>[]"></textarea>
                                                                        <input type="hidden" name="files<?php echo e($val->check_lists_id); ?>[]" class="form-control">
                                                                    </div>
                                                                <?php elseif($val->input_type == 2): ?>
                                                                    <div class="col-md-10 mt-2 mainbox<?php echo e($time); ?>">
                                                                        <input type="hidden" name="comments<?php echo e($val->check_lists_id); ?>[]" class="form-control">
                                                                        <input type="file" name="files<?php echo e($val->check_lists_id); ?>[]" class="form-control">
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="col-md-7 mt-2 mainbox<?php echo e($time); ?>">
                                                                        <textarea class="form-control" rows="1" placeholder="Enter Here..." name="comments<?php echo e($val->check_lists_id); ?>[]"></textarea>
                                                                    </div>
                                                                    <div class="col-md-3 mt-2 mainbox<?php echo e($time); ?>">
                                                                        <input type="file" name="files<?php echo e($val->check_lists_id); ?>[]" class="form-control">
                                                                    </div>
                                                                    
                                                                <?php endif; ?>
                                                                <div class="col-md-2 mt-2 text-center mainbox<?php echo e($time); ?>">
                                                                    <button class="btn btn-danger btn-deletes removeComments" check_lists_id="<?php echo e($val->check_lists_id); ?>" time="<?php echo e($time); ?>" input_type=<?php echo e($val->input_type); ?>>
                                                                        -
                                                                    </button>
                                                                </div>
                                                                
                                                            <?php endif; ?>
                                                            
                                                            
                                                        </div>
                                                        <hr style="border: 2px solid #000; width:100%;">
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php echo $__env->make('layouts.custom_partials.save_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-scripts'); ?>
<script src="/assets/plugins/select2/select2.min.js"></script> <!-- Select2 Js -->

<script type="text/javascript">
    
    $('.select2').select2();

    $(document).on('click', '.removeComments', function(event){
        event.preventDefault();
        let time = $(this).attr('time');
        $('.mainbox'+time).remove();
    });

    $(document).on('click', '.btn-delete', function(event){
        event.preventDefault();
        let time = $(this).attr('time');
        let client_audit_report_submit_id = $(this).attr('client_audit_report_submit_id');
        let filedelte = $(this).attr('filedelte');
        if(client_audit_report_submit_id) {
            $.ajax({
                url: '/audit-report/delete',
                type: "POST",
                data: { 
                    '_token' :"<?php echo e(csrf_token()); ?>",
                    client_audit_report_submit_id: client_audit_report_submit_id,
                    filedelte: filedelte,
                },
                success: function(res) {
                    location.reload();
                }
            })
        };
        $('.mainbox'+time).remove();
    });
    $(document).on('click', '.addComments', function(event){
        event.preventDefault();
        let check_lists_id = $(this).attr('check_lists_id');
        let input_type = $(this).attr('input_type');
        let time = new Date().getTime();
        let row ='';
        if(input_type == 1){
            row += '<div class="col-md-10 mt-2 mainbox'+time+'">';
                row += '<textarea class="form-control" rows="1" placeholder="Enter Here..." name="comments'+check_lists_id+'[]"></textarea>';
                row += '<input type="hidden" name="files'+check_lists_id+'[]" class="form-control">';
            row += '</div>';
        }else if(input_type == 2){
            row += '<div class="col-md-10 mt-2 mainbox'+time+'">';
                row += '<input type="file" name="files'+check_lists_id+'[]" class="form-control">';
                row += '<input type="hidden" name="comments'+check_lists_id+'[]" class="form-control">';
            row += '</div>';
        }else{
            row += '<div class="col-md-7 mt-2 mainbox'+time+'">';
                row += '<textarea class="form-control" rows="1" placeholder="Enter Here..." name="comments'+check_lists_id+'[]"></textarea>';
            row += '</div>';
            row += '<div class="col-md-3 mt-2 mainbox'+time+'">';
                row += '<input type="file" name="files'+check_lists_id+'[]" class="form-control">';
            row += '</div>';
        }
        
        row += '<div class="col-md-2 mt-2 text-center mainbox'+time+'">';
            row += '<button class="btn btn-danger removeComments" check_lists_id="'+check_lists_id+'" time="'+time+'">-</button>';
        row += '</div>';

        $('#comments'+check_lists_id).append(row);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaikhabdulshahid/Project/spcode/erp/resources/views/auditreport/client_reply.blade.php ENDPATH**/ ?>