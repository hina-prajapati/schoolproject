<?php

return [
	'timestamp' => ['created_at', 'updated_at'],
	'type_of_establishment' => [
		'Factory',
		'Shops',
		'ITES',
		'Hotel',
		'Others'
	],
	'input_type' => [
		'1' => 'textarea',
		'2' => 'file',
		'3' =>'textarea+file'
	],
	'periodicity' => [
		'1' => 'One Time',
		'28' => 'Monthly',
		'90' =>'Quarterly',
		'180' =>'Six Month',
		'360' =>'Year'
	],
	'audit_report_status' => [
		'pending',
		'start',
		'completed'
	],
	'type_of_govt' => [
		'Both',
		'Central',
		'State'
	],
	'type' => [
		'Rule',
		'Remittance',
		'Register',
		'Return'
	],
	'exclude_cd' => [],
	'User'=> [
	    'table' => 'users',
	    'prefix' => 'u_'
	],
	'AuditReportStatus'=> [
	    'table' => 'audit_report_status',
	    'prefix' => 'ars_'
	],
	'SubscriptionPlan'=> [
	    'table' => 'subscription_plan',
	    'prefix' => 'sp_'
	],
	'AuditHistory'=> [
	    'table' => 'audit_history',
	    'prefix' => 'ah_'
	],
	'AuditHistoryList'=> [
	    'table' => 'audit_history_lists',
	    'prefix' => 'ahl_'
	],
	'Establishment'=> [
	    'table' => 'establishment',
	    'prefix' => 'e_'
	],
	'Periodicities'=> [
	    'table' => 'periodicity',
	    'prefix' => 'p_'
	],
	'AssignSubscriptionPlan'=> [
	    'table' => 'assign_subscription_plan',
	    'prefix' => 'asp_'
	],
	'AuditReport'=> [
	    'table' => 'audit_report',
	    'prefix' => 'ar_'
	],
	'ClientAuditReportSubmit'=> [
	    'table' => 'client_audit_report_submit',
	    'prefix' => 'cars_'
	],
	'VendorAuditReport'=> [
	    'table' => 'vendor_audit_report',
	    'prefix' => 'var_'
	],
	'AssignCheckLists'=> [
	    'table' => 'assign_check_lists',
	    'prefix' => 'acl_'
	],
	'AssignCheckListsVendor'=> [
	    'table' => 'assign_check_lists_vendor',
	    'prefix' => 'aclv_'
	],
	'Category'=> [
	    'table' => 'category',
	    'prefix' => 'c_'
	],
	'CompanyProfile'=> [
	    'table' => 'company_profile',
	    'prefix' => 'cp_'
	],
	'FileHistory'=> [
	    'table' => 'file_history',
	    'prefix' => 'fh_'
	],
	'Laws'=> [
	    'table' => 'laws',
	    'prefix' => 'l_'
	],
	'CheckList'=> [
	    'table' => 'check_lists',
	    'prefix' => 'cl_'
	],
	'EmployeeAssign'=> [
	    'table' => 'employee_assign',
	    'prefix' => 'ea_'
	],
];